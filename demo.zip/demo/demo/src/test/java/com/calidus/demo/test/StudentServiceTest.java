package com.calidus.demo.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import com.calidus.demo.controller.StudentRestController;
import com.calidus.demo.model.Student;
import com.calidus.demo.repository.StudentRepository;
import com.calidus.demo.service.StudentService;
import com.calidus.demo.service.impl.StudentServiceImpl;

@RunWith(MockitoJUnitRunner.class)
public class StudentServiceTest {
	
	 @InjectMocks
	 StudentServiceImpl studentServiceImpl;
	     
	    @Mock
	    StudentRepository studentRepository;

	    
	    @Before
	    public void init() {
	        MockitoAnnotations.initMocks(this);
	        new Student(1L,"Software");
	        
	    }
	    
	    
	    @Test
	    public void getStudentsTest()
	    {
	    	List<Student> studentList=new ArrayList<Student>();
	    	studentList.add(new Student(1L,"Innominds"));
	    	studentList.add(new Student(2L,"software"));
	    	studentList.add(new Student(3L,"pvt ltd"));
	    	when(studentRepository.findAll()).thenReturn(studentList);
	    	List<Student> listStudent=studentRepository.findAll();
	    	assertEquals(3, listStudent.size());
	    }
	    
	    @Test
	    public void getStudentTest() {
	    	List<Student> studentList=new ArrayList<Student>();
	    	Student student=new Student(1L,"Innominds");
	    	when(studentRepository.findById(1L)).thenReturn(student);
	    	Student originalStudent=studentRepository.findById(1L);
	    	assertEquals(originalStudent.getId(), student.getId());
	    	
	    }
	    
	    
	   
	    
	    
}
