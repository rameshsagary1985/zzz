package com.calidus.demo.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import com.calidus.demo.controller.StudentRestController;
import com.calidus.demo.model.Student;
import com.calidus.demo.service.StudentService;

@RunWith(MockitoJUnitRunner.class)
public class DemoApplicationTests2 {
	
	 @InjectMocks
	 StudentRestController studentRestController;
	     
	    @Mock
	    StudentService studentService;

	    
	    @Before
	    public void init() {
	        MockitoAnnotations.initMocks(this);
	    }
	    
	    
	    @Test
	    public void getStudentsTest()
	    {
	    	List<Student> studentList=new ArrayList<Student>();
	    	studentList.add(new Student(1L,"Innominds"));
	    	studentList.add(new Student(2L,"software"));
	    	studentList.add(new Student(3L,"pvt ltd"));
	    	when(studentService.getStudentList()).thenReturn(studentList);
	    	List<Student> listStudent=studentService.getStudentList();
	    	assertEquals(3, listStudent.size());
	    }
	    
	    @Test
	    public void getStudentTest() {
	    	List<Student> studentList=new ArrayList<Student>();
	    	studentList.add(new Student(1L,"Innominds"));
	    	studentList.add(new Student(2L,"software"));
	    	studentList.add(new Student(3L,"pvt ltd"));
	    	when(studentService.getStudentList()).thenReturn(studentList);
	    	List<Student> listStudent=studentService.getStudentList();
	    	Student  actualStuent=studentService.getStudent(3L);
	    	
	    }
	    
	    
	    
	    
}
