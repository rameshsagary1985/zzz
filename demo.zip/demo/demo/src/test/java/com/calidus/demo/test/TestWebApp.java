package com.calidus.demo.test;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.calidus.demo.model.Student;
import com.calidus.demo.service.StudentService;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class TestWebApp extends DemoApplicationTests {
	
	@Autowired
	private WebApplicationContext webApplicationContext;
	
	
	@Autowired
    private StudentService studentService;

	private MockMvc mockMvc;

	@Before
	public void setup() {
		mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
	}
	 protected String mapToJson(Object obj) throws JsonProcessingException {
	      ObjectMapper objectMapper = new ObjectMapper();
	      return objectMapper.writeValueAsString(obj);
	   }
	 
	 protected <T> T mapFromJson(String json, Class<T> clazz)
		      throws JsonParseException, JsonMappingException, IOException {
		      
		      ObjectMapper objectMapper = new ObjectMapper();
		      return objectMapper.readValue(json, clazz);
		   }
	
	 
	 // mock test for adding the new student
	@Test
	public void testAddStudents() throws Exception {
		 String uri = "/api/saveStudent";
		 Student student = new Student(1L,"Innominds");
	      String inputJson = mapToJson(student);
	      MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.post(uri)
	    	         .contentType(MediaType.APPLICATION_JSON_VALUE)
	    	         .content(inputJson)).andReturn();
	    	      int status = mvcResult.getResponse().getStatus();
	    	      System.out.println(" test status from  testAddStudents "+status);
	    	      assertEquals(200, status);
	    	   
	}
	
	
	//mock test for get studnet details
	@Test
	   public void getStudentList() throws Exception {
	      String uri = "/api/students";
	      MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get(uri)
	         .accept(MediaType.APPLICATION_JSON_VALUE)).andReturn();
	      int status = mvcResult.getResponse().getStatus();
	      System.out.println(" test status from  getStudentList "+status);
	      assertEquals(200, status);
	      String content = mvcResult.getResponse().getContentAsString();
	      Student[] productlist = mapFromJson(content, Student[].class);
	      assertTrue(productlist.length > 0);
	   }
	
	
	@Test
	   public void updateProduct() throws Exception {
	     String uri = "/api/updateStudent/{studentId}";
	     Student student = new Student(1L,"Innominds");
	      String inputJson = mapToJson(student);
	      MvcResult mvcResult =  mockMvc.perform(MockMvcRequestBuilders.put("/api/updateStudent/{studentId}",1L)
	    		  .contentType(MediaType.APPLICATION_JSON_VALUE)
	    	         .content(inputJson)).andReturn();
	       
	      
	      int status = mvcResult.getResponse().getStatus();
	      System.out.println(" test status from  updateProduct "+status);
	      assertEquals(200, status);
		
	
	   }
	
	@Test
	   public void deleteProduct() throws Exception {
	     String uri = "api/deleteStudent/{studentId}";
	     Student student = new Student(1L,"Innominds");
	      String inputJson = mapToJson(student);
	      MvcResult mvcResult =  mockMvc.perform(MockMvcRequestBuilders.put("api/deleteStudent/{studentId}",1L)
	    		  .contentType(MediaType.APPLICATION_JSON_VALUE)
	    		  .content(inputJson)).andReturn();
	       
	      
	      int status = mvcResult.getResponse().getStatus();
	      System.out.println(" test status from  deleteProduct "+status);
	      assertEquals(404, status);
		
	
	   }
	
	
	 @Test
	    public void testGetStudents() {
	        List<Student> studentList	 = studentService.getStudentList();
	 System.out.println(studentList);
	        assertTrue(studentList.size()>=0);
	 
	    }
	
	

}
