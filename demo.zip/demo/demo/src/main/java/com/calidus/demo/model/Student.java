package com.calidus.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Student")
public class Student {


	 @Id
	 @GeneratedValue(strategy= GenerationType.IDENTITY)
	private Long id;
	 public Long getId() {
		return id;
	}
	@Override
	public String toString() {
		return "Student [id=" + id + ", studentName=" + studentName + "]";
	}
	public void setId(Long id) {
		this.id = id;
	}
	
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	@Column(name="STUDENT_NAME")
	private String studentName;
	public Student(Long id, String studentName) {
		super();
		this.id = id;
		this.studentName = studentName;
	}

}
