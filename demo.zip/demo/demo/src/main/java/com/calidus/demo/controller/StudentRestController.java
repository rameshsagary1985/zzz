package com.calidus.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.calidus.demo.model.Student;
import com.calidus.demo.service.StudentService;


//It is a student controller written the logic to get all Curd operations
@RestController
public class StudentRestController {
	
	@Autowired
	private StudentService studentService;

	public void setStudentService(StudentService studentService) {
		this.studentService = studentService;
	}
	
	
	//Written the logic to get all the students information 
	@GetMapping("api/students")
	public List<Student>  getStudents()
	{
		System.out.println("Students: List"+studentService.getStudentList());
		return studentService.getStudentList();
		
		
	}
	
	//this method is used to get the specific student details
	@GetMapping("api/student/{studentId}")
	public Student getStudent(@PathVariable(name="studentId")Long studentid)
	{
		System.out.println("Student ::"+studentService.getStudent(studentid));
		return studentService.getStudent(studentid);
		
	}

	// By using this method we can save the students 
	@PostMapping("api/saveStudent")
	public void saveStudent(Student student)
	{
	
		studentService.saveStudent(student);
		System.out.println("student details saved"+student);
	}
	
	//By using this method we can delete the specific student details
	@PutMapping("api/updateStudent/{studentId}")
	public void updateStudent(@RequestBody Student student,@PathVariable(name="studentId")Long studentId)
	{
		Student fetchedstudent=studentService.getStudent(studentId);
		if(fetchedstudent!=null)
		{
			studentService.updateStudent(student);
			System.out.println("student details are updated");
		}
		else
		{
			System.out.println("id is not present");
		}
	}
	
	@DeleteMapping("api/deleteStudent/{studentId}")
	public void deleteStudent(@PathVariable(name="studentId")Long studentId)
	{
		System.out.println("student deleted successfully");
		studentService.deleteStudent(studentId);
	}
	
	
}
