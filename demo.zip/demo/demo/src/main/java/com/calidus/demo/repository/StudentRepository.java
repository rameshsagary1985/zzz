package com.calidus.demo.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.calidus.demo.model.Student;
@Repository
public interface StudentRepository extends JpaRepository<Student, Long> {

	
	// it will fetch the student details by using id
	Student findById(Long studentId);

}
