package com.calidus.demo.service;

import java.util.List;

import com.calidus.demo.model.Student;

public interface StudentService {
	
	 public List<Student> getStudentList();
	  
	 public Student getStudent(Long studentId);
	  
	 public void saveStudent(Student student);
	  
	 public void deleteStudent(Long studentId);
	  
	 public void updateStudent(Student student);

}
