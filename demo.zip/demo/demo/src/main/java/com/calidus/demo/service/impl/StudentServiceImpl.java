package com.calidus.demo.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.calidus.demo.model.Student;
import com.calidus.demo.repository.StudentRepository;
import com.calidus.demo.service.StudentService;
@Service
public class StudentServiceImpl implements StudentService {
	
	public void setStudentRepository(StudentRepository studentRepository) {
		this.studentRepository = studentRepository;
	}

	@Autowired
	 private StudentRepository studentRepository;

	// returns all the students list
	public List<Student> getStudentList() {
		return studentRepository.findAll();
	}

	// return  single student  
	public Student getStudent(Long studentId) {
		//Student optStudent=studentRepository.findById(studentId);
		return studentRepository.findById(studentId);
				
	}

	//used to save the Studetn details
	public void saveStudent(Student student) {
		studentRepository.save(student);

	}

	//used to delete the single student 
	public void deleteStudent(Long studentId) {
		studentRepository.delete(studentId);

	}

	// used to  update the student info
	public void updateStudent(Student student) {
		studentRepository.save(student);

	}

}
